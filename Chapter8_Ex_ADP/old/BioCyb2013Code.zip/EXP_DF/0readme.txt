List of the main files:

main_show_stiffness.m         -- Generates the stiffness ellipses
main.m                        -- Generates the trial trajectories, velocity, and endpoint force curves
SimuVF30.m                    -- Generates a series of control policies throung Online learning