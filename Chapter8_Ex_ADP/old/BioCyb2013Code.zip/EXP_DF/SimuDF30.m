global Kadp
para;Kadp=K0;

for j=5:30
    j
    ADPlearning;
end


