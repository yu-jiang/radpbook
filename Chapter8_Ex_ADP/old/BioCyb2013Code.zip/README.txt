

EXP_VF\main.m  
---> Fig 1 and Fig 2

EXP_VF\main_plot_movement_duration.m
---> Fig 3

EXP_VF\main_show_stiffnessVF.m
---> Fig 4

EXP_DF\main.m  
---> Fig 5 and Fig 6


EXP_DF\main_show_stiffness.m
---> Fig 7


Fitts\main.m
---> Fig 8 and Table 2