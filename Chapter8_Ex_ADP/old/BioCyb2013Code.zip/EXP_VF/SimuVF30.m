% learning
global Kadp
para;Kadp=K0;

for j=1:30
    disp(['Simulating the ', num2str(j), '-th trial'])
ADPlearning; 
end


