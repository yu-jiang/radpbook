List of the main files:

main_show_stiffnessVF.m       -- Generates the stiffness ellipses
main.m                        -- Generates the trial trajectories, velocity, and endpoint force curves
main_plot_movement_duration.m -- Generates the movement duration and distance of each trial
SimuVF30.m                    -- Generates a series of control policies throung Online learning